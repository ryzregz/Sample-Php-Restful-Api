<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {
	
	 public function __construct(array $data = null){
			
                   parent::__construct($data);
	 }

	 public function get_locations($site_code){
            $this->db->select('*'); 
            $this->db->where('site_code', $site_code);  
            $query = $this->db->get('tbl_locations');
            if (! $query->num_rows() > 0 )
            {
                    return false;
            }
            
            return $query->result();
        }

         public function get_categories(){
            $this->db->select('*'); 
            $query = $this->db->get('tbl_categories');
           if (! $query->num_rows() > 0 )
            {
                    return false;
            }
            
            return $query->result();
        }
        public function get_category_id($category_name){
            $this->db->select('id'); 
            $this->db->where('name', $category_name);  
            $query = $this->db->get('tbl_categories');
           if (! $query->num_rows() > 0 )
            {
                    return false;
            }
            $row = $query->row();

            return $row->id;  
            
        }

        public function get_stock_sheet($location_id,$category_id){
            $this->db->select('*'); 
            $this->db->where('location_id', $location_id);  
            $this->db->where('category_id', $category_id);  
            $query = $this->db->get('tbl_stock_sheet');
           if ($query->num_rows() == 0 )
            {
                    return false;
            }else{
                return $query->result();
            }
            
            
        }


        public function get_user_stock_entry($user_id){
             $this->db->select('*'); 
            $this->db->where('user_id', $user_id);   
            $query = $this->db->get('tbl_product_transactions');
           if ($query->num_rows() == 0 )
            {
                    return false;
            }
            
            return $query->result();

        }

         public function addProduct($add_data)
    {
            if(! $this->db->insert('tbl_product_transactions',$add_data)){
                    $this->logError($this->db->_error_number()." ".$this->db->_error_message()); 
                    return false;
            }

            return $this->db->insert_id();
    }
	}
