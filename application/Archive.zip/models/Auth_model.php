<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {
	
	 public function __construct(array $data = null){
			
                   parent::__construct($data);
	 }


public function login($username,$pass,$ip_address,$user_platform)
	{	
		$now = new DateTime ( NULL, new DateTimeZone('UTC'));
		$ip_addr = ip2long($ip_address); //its opposite is long2ip. MySQL functions are INET_ATON and INET_NTOA
		//$now = new DateTime ();
		$password = md5($pass);
		$this->db->select('id,user_status');
		$this->db->where('username', $username); 
		$this->db->where('password', $password); 
		$query = $this->db->get('tbl_users');
		if (! $query->num_rows() > 0 )
		{
			return false;
		}
		
		$id = 0;
		/*foreach ($query->result() as $row)
		{
			$id = $row->id;
		}*/
                $row = $query->row();
		
		$data = array('last_login' =>$now->format('Y-m-d H:i:s'), 'last_ip_address' => $ip_addr, 'last_client_platform' => $user_platform);
		$this->db->where('id', $row->id);
		$this->db->update('tbl_users', $data); 
		
		if(! $this->db->affected_rows()){
			return false;
		}              
                
                $data = array('active' => 0);
		$this->db->where('user_id', $row->id);
		$this->db->update('auth_token', $data); 
                				
		return $row;
	}

	 public function insert_token($data)
	{	
            if(! $this->db->insert('auth_token',$data)){
                    logError($this->db->_error_number()." ".$this->db->_error_message()); 
                    return false;
            }
                				
	    return true;
	}


	 public function get_user_details($id){
            $details = array();
            
            $this->db->select('id,msisdn,username');
            $this->db->where('id', $id);  
            $query = $this->db->get('tbl_users');
            if (! $query->num_rows() > 0 )
            {
                    return false;
            }
            $details['auth'] = $query->row();
            
            $this->db->select('f_name,l_name,'
                    . 'town,county,site_code');
            $this->db->where('id', $id);  
            $query2 = $this->db->get('tbl_users');
            if (! $query2->num_rows() > 0 )
            {
                    return false;
            }
            $details['profile'] = $query2->row(); 
            return $details;
            
        }




	}
